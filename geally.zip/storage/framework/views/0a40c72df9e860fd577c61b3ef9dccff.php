<div class="relative">
    <style>
        #products-swiper .swiper-button-next,
        #products-swiper .swiper-button-prev {
            background: rgba(71, 80, 72, 0.95);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            color: var(--color-creamDark) !important;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            border: 2px solid var(--color-accent);
        }
        #products-swiper .swiper-button-next:hover,
        #products-swiper .swiper-button-prev:hover {
            background: var(--color-accent);
            transform: scale(1.15);
            box-shadow: 0 6px 20px rgba(189, 144, 111, 0.6);
        }
        #products-swiper .swiper-button-next:after,
        #products-swiper .swiper-button-prev:after {
            font-size: 22px;
            font-weight: bold;
        }
        #products-swiper .swiper-button-next {
            right: 10px;
        }
        #products-swiper .swiper-button-prev {
            left: 10px;
        }
        #products-swiper .swiper-button-next.swiper-button-disabled,
        #products-swiper .swiper-button-prev.swiper-button-disabled {
            opacity: 0.3;
        }
    </style>
    <div class="swiper group" id="products-swiper">
        <div class="swiper-wrapper">
            <?php $__currentLoopData = ($products ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <!-- <a href="<?php echo e(route('products.show', $product)); ?>" class="block"> -->
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-96 object-fit rounded-xl shadow" />
                        <?php else: ?>
                            <div class="w-full h-96 bg-[color:var(--color-primary)]/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-image text-3xl text-[color:var(--color-secondaryDark)]"></i>
                            </div>
                        <?php endif; ?>
                        
                    <!-- </a> -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="swiper-button-next !hidden md:!flex"></div>
        <div class="swiper-button-prev !hidden md:!flex"></div>
        <div class="swiper-pagination"></div>
    </div>
</div>

<script>
    (function(){
        const container = document.getElementById('products-swiper');
        if (!container) return;
        
        const initSwiper = function() {
            if (container.swiper) return; // Already initialized
            
            if (typeof Swiper === 'undefined') {
                setTimeout(initSwiper, 100);
                return;
            }
            
            const productCount = <?php echo e(count($products ?? [])); ?>;
            
            new Swiper('#products-swiper', {
                loop: true,
                loopedSlides: productCount > 3 ? Math.ceil(productCount / 3) * 3 : productCount,
                speed: 600,
                spaceBetween: 20,
                slidesPerView: 1,
                slidesPerGroup: 1,
                autoplay: { 
                    delay: 3000, 
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true
                },
                breakpoints: {
                    640: { 
                        slidesPerView: 2, 
                        slidesPerGroup: 2,
                        spaceBetween: 20
                    },
                    1024: { 
                        slidesPerView: 3, 
                        slidesPerGroup: 3,
                        spaceBetween: 20
                    },
                },
                navigation: { 
                    nextEl: container.querySelector('.swiper-button-next'), 
                    prevEl: container.querySelector('.swiper-button-prev') 
                },
                pagination: { 
                    el: container.querySelector('.swiper-pagination'), 
                    clickable: true,
                    dynamicBullets: true
                },
                grabCursor: true,
            });
        };
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initSwiper);
        } else {
            setTimeout(initSwiper, 50);
        }
        
        // Fallback: try after window load
        window.addEventListener('load', function() {
            if (!container.swiper && typeof Swiper !== 'undefined') {
                initSwiper();
            }
        });
    })();
</script>
<?php /**PATH C:\Users\AMRO\Desktop\ali\geally\resources\views/partials/carousel.blade.php ENDPATH**/ ?>