

<?php $__env->startSection('title', 'View Product - Geally Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">Product Details</h2>
    <div class="flex space-x-2">
        <a href="<?php echo e(route('admin.products.edit', $product)); ?>" 
           class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
            <i class="fas fa-edit mr-2"></i>Edit Product
        </a>
        <a href="<?php echo e(route('admin.products.index')); ?>" 
           class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">
            <i class="fas fa-arrow-left mr-2"></i>Back to Products
        </a>
    </div>
</div>

<div class="bg-white shadow-md rounded-lg p-6">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Product Images -->
        <div>
            <h3 class="text-lg font-medium text-gray-800 mb-4">Images</h3>
            
            <?php if($product->image): ?>
                <div class="mb-6">
                    <h4 class="text-md font-medium text-gray-700 mb-2">Primary Image</h4>
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" 
                         alt="<?php echo e($product->name); ?>" 
                         class="w-full h-64 rounded-lg object-cover">
                </div>
            <?php endif; ?>

            <?php if($product->images && count($product->images) > 0): ?>
                <div>
                    <h4 class="text-md font-medium text-gray-700 mb-2">Additional Images (<?php echo e(count($product->images)); ?>)</h4>
                    <div class="grid grid-cols-2 gap-4">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('storage/' . $image)); ?>" 
                                 alt="<?php echo e($product->name); ?>" 
                                 class="w-full h-32 rounded-lg object-cover">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(!$product->image && (!$product->images || count($product->images) == 0)): ?>
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-image text-4xl mb-2"></i>
                    <p>No images uploaded</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Product Details -->
        <div>
            <h3 class="text-lg font-medium text-gray-800 mb-4">Product Information</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Product Name</label>
                    <p class="mt-1 text-lg text-gray-900"><?php echo e($product->name); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Price</label>
                    <p class="mt-1 text-2xl font-bold text-green-600">AUE <?php echo e(number_format($product->price, 2)); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Created</label>
                    <p class="mt-1 text-gray-900"><?php echo e($product->created_at->format('M d, Y \a\t g:i A')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Last Updated</label>
                    <p class="mt-1 text-gray-900"><?php echo e($product->updated_at->format('M d, Y \a\t g:i A')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Total Images</label>
                    <p class="mt-1 text-gray-900">
                        <?php echo e(($product->image ? 1 : 0) + count($product->images ?? [])); ?> image(s)
                    </p>
                </div>
            </div>

            <div class="mt-8 flex space-x-4">
                <a href="<?php echo e(route('admin.products.edit', $product)); ?>" 
                   class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                    <i class="fas fa-edit mr-2"></i>Edit Product
                </a>
                <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>" 
                      class="inline" 
                      onsubmit="return confirm('Are you sure you want to delete this product? This action cannot be undone.')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700">
                        <i class="fas fa-trash mr-2"></i>Delete Product
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\AMRO\Desktop\ali\geally\resources\views\admin\products\show.blade.php ENDPATH**/ ?>