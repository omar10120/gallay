<?php
    $defaultCategories = ['All'];
    $list = isset($categories) && is_array($categories) && count($categories) ? array_merge($defaultCategories, $categories) : $defaultCategories;
    $active = request('category', 'All');
    $slugify = function($text){
        return strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $text)));
    };
?>

<div class="w-full">
    <div class="flex flex-wrap gap-3 items-center w-full justify-center">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($isActive = ($cat === 'All' && ($active==='All' || !$active)) || ($slugify($cat) === strtolower($active))); ?>
            <?php ($param = $cat === 'All' ? null : $slugify($cat)); ?>
            <a href="<?php echo e($param ? url()->current() . '?category=' . $param : url()->current()); ?>"
               class="px-4 py-2 rounded-full border transition font-medium"
               style="
                    border-color: var(--color-accent);
                    color: <?php echo e($isActive ? 'var(--color-creamDark)' : 'var(--color-creamDark)'); ?>;
                    background: <?php echo e($isActive ? 'var(--color-accent)' : 'transparent'); ?>;
               "
            >
                <?php echo e($cat); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php /**PATH C:\Users\AMRO\Desktop\ali\geally\resources\views/partials/categories.blade.php ENDPATH**/ ?>