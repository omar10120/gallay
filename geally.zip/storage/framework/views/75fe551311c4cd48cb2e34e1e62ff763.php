

<?php $__env->startSection('title', 'FastMenu - Beautiful Images Gallery'); ?>

<?php $__env->startSection('content'); ?>
<div id="gallery" class="py-12">
    <?php echo $__env->make('partials.categories', ['categories' => $categories ?? []], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="h-6"></div>
    <?php if($products->count() > 0): ?>
        <?php echo $__env->make('partials.carousel', ['products' => $products], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="h-8"></div>
    <?php endif; ?>
   

    <?php if($products->count() > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded-2xl border-2" style="border-color: var(--color-accent); background: rgba(0,0,0,0.06);">
                    <div class="relative m-2 rounded-xl overflow-hidden" style="background: rgba(0,0,0,0.08);">
                        <!-- <a href="<?php echo e(route('products.show', $product)); ?>" class="block"> -->
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-[460px] object-cover" />
                            <?php else: ?>
                                <div class="w-full h-[460px] bg-[color:var(--color-primary)]/30 flex items-center justify-center">
                                    <i class="fas fa-image text-4xl text-[color:var(--color-secondaryDark)]"></i>
                                </div>
                            <?php endif; ?>
                        <!-- </a> -->

                        <div class="absolute left-4 -bottom-6 flex items-center gap-4">
                            <a href="tel:#" class="w-12 h-12 rounded-full bg-white shadow flex items-center justify-center text-[color:var(--color-primaryDark)] hover:scale-105 transition">
                                <i class="fa-solid fa-phone"></i>
                            </a>
                            <a href="#" class="w-12 h-12 rounded-full bg-white shadow flex items-center justify-center text-green-600 hover:scale-105 transition">
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>
                            <a href="#" class="w-12 h-12 rounded-full bg-white shadow flex items-center justify-center text-[color:var(--color-primaryDark)] hover:scale-105 transition">
                                <i class="fa-regular fa-share-from-square"></i>
                            </a>
                        </div>
                    </div>

                    <div class="px-4 pb-4 ">
                        <div class="rounded-lg mb-2 flex justify-around items-center h-full p-2" style="background-color: var(--color-primaryDark);">
                            <div class="  text-[color:var(--color-creamDark)] font-semibold flex items-center">
                                <div class="uppercase tracking-wide"><?php echo e(number_format($product->price, 0)); ?> AED</div>
                                <div class="opacity-90 text-sm">&nbsp;</div>
                            </div>
                             <div class=" text-[color:var(--color-creamDark)] font-semibol flex items-center">
                                    <div class="uppercase tracking-wide"><?php echo e($product->name); ?></div>
                                    <div class="opacity-90 text-sm">&nbsp;</div>
                                </div>
                        </div>
                      
                        
                    </div>
                

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <?php if($products->hasPages()): ?>
            <div class="mt-12 flex justify-center">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    <?php else: ?>
        <!-- Empty state -->
        <div class="text-center py-16">
            <div class="w-20 h-20 sm:w-24 sm:h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-images text-gray-400 text-2xl sm:text-3xl"></i>
            </div>
            <h3 class="text-lg sm:text-xl font-semibold text-gray-800 mb-2">No Images Yet</h3>
            <p class="text-gray-600 mb-6 text-sm sm:text-base">Check back soon for our beautiful image collection!</p>
        
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\AMRO\Desktop\ali\geally\resources\views/products/index.blade.php ENDPATH**/ ?>